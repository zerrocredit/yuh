var version_ = 'jsjiami.com.v7',
	_0x5276 = (function() {
		return [...[version_, 'pFjDBsNSTjDqiYaPFmi.fcDWSoVhmw.HvNn7SlhR==', 'aCkFp8k3WOW', 'd8k7jCkHmmkPzNtdQaqU', 'W61gbexcIq', 'WOXfbfWSWOOlWQZdQ8omftZcOG', 'W73cRSogWPRcKG', 'fmk/W73dQmoA', 'WPFdH1L/W54', 'W6NdN3hdOx4', 'AmkhzJ3cPCoI', 'v8ovh8ocWPW', 'hmk7W53dU8oPWOaSWQq5WQO', 'WRjHWRVcQCodgKBcGW', 'C8oujSosWQS', 'qmo2WPDElq', 'neBdImkJoCknsCohbmkn', 'W4n4W7xdSSkfnhr4W5q', 'xCoTWObx', 'gtBdNmkaW4G', 'cmklWRhcPmku', 'zSkuW4WuvSo+WOVcKGtcGmool8oFWPy', 'WOHeW5hdPf4', 'WRKUvCkUWPm', 'WQP+ewq7', 'WQddUu7dGua', 'aqpdUmoUga', 'BCkrW48fuCo8WRhcUqlcGSoE', 'W7iYWOhcOmoxkwy', 'WPZdLu1EmW', 'gCkMWOdcP8kh', 'W6SNW77dP2C8W5WJ', 'WR9DW5hcG8oFW4PHW6m8AW', 'WPmiW7RcQSk7W4BcHmoH', 'WQKOtCk4WO9KW5JdVJZdI0FdIYJdJw3dQbrJ', 'zSknys7cNSo/BSoj', 'Cmk4WQmiW7RdKSoOW6XNywrT', 'W7lcRCkU', 'WQBdK2VcRCoLWOFcLSo4WPra', 'WOrQjwRdGW', 'W4vtW58', 'cCkYlmkRWP17WP3dHhTB', 'WP9FW6BcUSoGBq', 'W5Pfxmkj', 'dSk3c8kGWPDsW4hdLL9RD3adleVcOmolW4vWymktWQS4WOlcOmk6W7iRBafEe3uCW5FdVbPMmZ7cV0VdL8otWP3cNgOaWQ7dRmo6WQpdTXOeW4RcOmoKW6NdLWFcP11XBCkAWQ1lWP51W57cJhJcN8oCpSk5W7HmW7qigM7cM8klWQbSmMRcOrVdKSowvY5kcCk9BKLNgKHDb8oVe8oWWQf0W6jAzWdcNmo+W7HyjcbwWOVdImoUkgNcHKnvCSkrpMDWW7xdJMxcRmool8oGWQ/dN8oTW6BdTSoeW5RdLaFdHuzErCoBzmkvW7uKau7cVaFcTIGVySo9WOG/WO3cP8o7W73cVZFcGqxdOeZcMMPoveqeWQnBdfqEW6NdLCkNW6m8AbqbnCo4WRjzWO1GWRnQxCo7C8oMWPxcRsRcHColWPRcLezKWOWPFSkoFGP8rsddH8ozdL5nW5BcNXBdVCk7iSk3WQ9qW7ODWOb8nclcKsuTtLm+W64IW5hdOCk/WR0CmmoFBMBdLbBcQSo0WO8tDSo6WQxdPYhcKmkqDmoFWOvRWQxdL8o8k07dOIpdI8oJWOdcKmkoCSkoW5ZcLmoIycBcHCo1bb7cPsr3W68oWPJcPxdcKCkJvK1KkG/cJCoyW5jRASkEWQq7hSofW5NdMmoWnCo9aSkyWQetWRKRWPK0WP3cHx9xW43cIezvwSo8W4KOW6WTnMhdUq3dGdr6zmoMW6RcKWv6WR0mWP8mWRRdUSojwGddNbWuWRdcPGe+W7ddU8oJWQvUAbBcNSkDrmoxW5nkBSkmWQhdTe5OW6pdQuzLW47dNCkbg8oSWQ/dQe3dRmo/WPnggmoJdZW6W45zW5SbqMFcGSoTEGZdQWRdUmkld8koBK7dUmoSrSkJWOflWPdcPa9FW4hdMczaowP3nvxcVrWNW79JWPTLg8opz8k4hCkEW5WRWONcUYFdO8oWWR0eW7xdSSkRW5pdOw91W5apW4ndW74NgmoEWOFdT8oRWP8WevHYAIVdUmo0mmksaSkwW4VcPJ5LW7hdPmoWWRRdT8oJtqW1v2NcP8kSWR10jcNcRSo5WRpdLmkdW4PnWQjxW7/cUCo/wCofpSojWQhdTadcTCoGqeiUF8oTvCo6vrGnW605W5lcGSkYrgJcOJZcVLldTSoAcJezEWVcTg7dNXhdQcuIWOBcQmovW4pcI8kHnSoOgv/cHb7dISoXbmoPW4FdISkLCLxcSLNcGCoojSkcW79CW6aKWPHzW5lcOr0SW780WQFcOSkfW5VcS8o1gCkOlqRdQ31QtmkeqCoCrw48etWjWRSvagK0bbJdTXxdTZBcI1bVECkmW67dSSo9W6mSW7mRcX5CB3pdPdmIW5nxzCk3W5ZcTqyUWRpcQCkYF8kGzqT1WQvKsSkjW5/cH0tdOxyyWR7dGSkiWO3dJttcQcqXoYJcH8o/yKHAWRNcVSoqDmo+W63dMdvtW4CfWQ7cKxhcSMDGW7hcGComW5r0WOtdLCoRWRHxWRiOqmoWBHW+WP3dNCkhcrHZoaPSudaYcMpdQbGvW5/cUSodzxWnqmkjWPFcKmkEWO7dPdxdL8k4WOZdHmkfgmkQwc9JW6GKwmooW5JdNWFdJSoKW5pdQmkIWPeTdmogdu/dKhNcRaZdNSk3W5VdNCocWO/dOCkVt8kPWPhdRIZdMJiyWPFcMCknkmoAWQGfW7hcPCoUWPHIWPGSW6JdLrDZaKRdLL0usWmrW5JdG8koW7xdQb/cUCoYWQpdOmkuW6hdHuxdSLldUGr7u17dReuIF3P+WPZcVCoNaCkrW47cJmoPWOLFW5lcQ8oRmCo3A0PYe8kYW5OFWOdcQCo1W4yWW6vbW71QnIVdQJFcJ8kjfmkzWP9eWOJcMSkjWQmAW6uIWRxdPxG7WR8OWPZdRSkdWRRdOmoqWRJcPc/cM8oQzmk1WRP2WQldN3WAxqJcKq7dI8kCW4XzWOpdPCoCawtcUSotWQpcPI8JguDxW6PZWRddOX4rj1RdKrzJWOmLW4tdQSohpc/dULNdL8o1fs4xBmklW7uxtSoeWOdcI8oKWRX0W4NdK8k2gmkoW4j6DSkUD8kolghcG8kTWOBdSCkAdCkyWRGWW5nwWPpcNeydjve6WOPfDa7dPXBcHt3cSmk2sgiyWR5wb8o6WPJcT8kTW54vDSojW6pcNCkEW4H2W5CFk8kCW7nnW5lcNLavhIvhC8kiWPm9W5P+AhXypCkfW7r+lrPCp8ktaWxdRSofW7e5e1ZdVmoZWRxdJftcPY1tESocWO9fW64CWONcHCoDi0zAhmkxWP8YE8k5WPCtechcQ2HZWQtdPSk7WP0WaCkqW4j4WQeOWQrsW5SxW7j9m3/cPSoAWR4QrSopWQJdSCkOW5DJBSkddhLBr8kpWRtcL8kfdmkJgGpcSCkPDCoyW4hdUJumW6VcVCkxW5awW5bdW6ddVr9DqXXwW5lcTNFcIwyhW5jhdmk8W6aWWRpdOxnRiuz9WRueW6hdISkvW4arW5RdOmkDWRqsW7NcS8kaWO8JF0WFW7VdOSomrxZdRCoBdmkuWR56W6hcISkTW7xdS8khmSkiwdBdS8oXwmkVESkiW54HW48cW70NWQ8kb0xcPmk2W5H9r8oCqmojhCo5W5lcPMm5W64FWRlcK8kYy8oPWPPQECkKW7ZcVupdKvxcMCoSshZcQCo3B8oEW6ddTrxcO3GJvcNcLM/cJhSCW7ZcSSoKW6PED8o4WRyMlIlcRNVdP8kzemk/WQNdTL3dHW', 'n3RdJmkOba', 'q3tcKCocW4zc', 'W7hdHNBdLgu', 'F8oGdSoj', 'W7PkdeJcTa', 'WQKYtCkWWRvyW7JdKdldNq', 'j8oGW75eWPtcGCosW4j9va', 'qSoLisC0gCkkWQCI', 'fSkItwxcPmo2W5ldHCk5W4hdPW', 'WPnPW6maW5q', 'w3JcRSokp8kXWRVcGq', 'aSk8vhtcS8oDW7pdH8k1W47dTW', 'oq3dKmoAp8k6', 'WR7dSmkbWPXB', 'W5FdJxddUvK', 'nJakWRRdMq', 'WQ7dT8o2W7ddJa', 'WR9qW7OUW5m', 'W7NcUaNdJg8DDHbuW7KR', 'WObVEJy', 'W57cJ8oPWP3cJa', 'WOO1zdZdRmoODmkqW5nsW55yW6SJdu5vrG', 'zSo4eHVdOKDksLxcTw0N', 'W49XW5ZdPmkH', 'udBdJSo7E8kAW77cVSo8W7aUW7RcTfjiWOOVqeGNArTJWOxcTX3cOSktuCoNBh/dNsRcR8oVW4H0BCk4ESoTxtihEq', 'W7mkWO3dUmos', 'qCoNWOnDpSk3', 'sSoPbCovWP7dRCoIW7nhWPZcRa', 'WRNdMgPq', 'b8kTwNdcPa', 'n8kHtYlcOG', 'WPzxkeNdIW', 'WQFdR8o/W7ddJwKIW6vQWPSFFCkfD8o5DHddSG', 'whRdJCkI', 'CZBcHqTj', 'WR1xW5OhW4dcNtS9W5C', 'fmkKtwxcUa', 'C8oUfJNdG0u', 'd2xdKZnPz8kRwmoI', 'WQPYW4BdQ2iy', 'qSkgW7WAxq', 'aX3cUmoMaq', 'WPbiW6NcP8oTvNXiW6pcImoaWONcVXhdP1mYja', 'nbJdJSoyjCk2WQinWOKIpG', 'og3dNCkxcq', 'W4ZcLSkeWPXsWOlcMmkd'], ...(function() {
			return [...['W7RcRmoNWOJcOxdcU8kEjIWP', 'i8oUW6LKWRK', 'WQPKW5BdSwyEW7a0WOO', 'W71nWOi', 'WRXfbMRdPW', 'W78iWQddGSoY', 'W6q+WOlcVmoAk3O', 'W6FcTc7dRuu', 'W7JcPWRdTvG', 'WOP0W5RdPL8jW6OPWOWNAG', 'W5uFWPJcVCo1', 'BGjEjmoS', 'W4JcLmoCW6aaW7ZdUSkcW6pdM8kgd8oT', 'e8oQW6DrWRhcGmoEW4e0', 'jCkxqZVcUq', 'WQ3dS2vsj3fgWOS5W43cISkbi8oIWO0m', 'lCk6x0dcIG', 'WR3dV3Djp3W', 'yLhcJSkiE8oQW5yJWO8LpSoAFG', 'WQDDW58TW5dcVW', 'jSoQW6r1WQ/cGCowW4b7vg94v8oP', 'WPbvW6BcRSoGD01GW5JcHCoy', 'W7JcLtNdS1S', 'W41SW6pcSmkm', 'WPbFW6BcQCoXDW', 'WPSAhmo5WPJcS8oEnCoVdaxcHvLBW6ex', 'WQX/W53dTMSJW7SWWOGJEW', 'emk4xx3cUa', 'amk+jmkOWO8', 'WRKqg8onWPRcHCoEjSkUfW/dPa', 'WRFdImotW5pdJG', 'l8keAbFcQq', 'W6LkehlcTSkMCmoqDmoZW6RdKwGrx28', 'WPXca04SWP0NWQ7dQq', 'mG3dISo4j8k3WOWaWO46gmo7t8oq', 'mLddMCkqhSkCv8olbCkmCmkV', 'lrZcV8oYaq', 'd3/dGCkalG', 'cSkDCwlcHW', 'nG8XWQZdSvNcM8oXEG', 'WOHBdMS0', 'W6ihdKBcQ8krn8kDn8oGW6RdG3GMxN7dRXqeAG', 'atlcLmogiG', 'WR7dTCk9W4tdOqNcISk9mq4ula', 'fmk3ytRcPKy', 'W7/cRCo+WQNcQg3cVmkdiJ05aCkNW4VdK8o2', 'W7ddNKFdNKO', 'pCkypCk9WPG', 'W6iGFtldHZZcTxSF', 'xgxcHSojW5C', 'W4ZcRtb6WOi', 'as/cLmoGjmks', 'hIhcK8oSW5nJBmoC', 'WRhdVe7dSKi', 'emkcgCk4WRm', 'gmknWQ3cQCkfhvddSCk/WORcLcq6', 'xHLbi8of', 'WPtdN1HeoG', 'qmoMWOv9kSk4', 'g08As8kyW5dcPmkuzSkiW54', 'WQK1qmkTWOq', 'pqa8WQldPgpcOmojwmo+', 'WQ13WPZdQ8kGWO4GWP3cV8oFcW', 'dSkOyhxcSW', 'WPddQvxdUKqpg8k1W5G', 'bHRdSSoYpG', 'W7HCW5FdHSkC', 'l8kUj8kScq', 'kmk6ChxcSq', 'imoHW7vMWPm', 'W67cHSksdNHdW5yQW4qImgS', 'cSkDCfdcIq', 'W7PnavxcHCkBCCocvmo1', 'W4SgcCop', 'CtFcHcL5', 'kSktpmkWdG', 'bs/cK8oGomko', 'dsStWPJdQa', 'WQ/dRmkKWOry', 'WOaPAYpdP8oZzmkwW5a', 'WRmfW7RcRIG', 'W5ncW4/cQCk5', 'WRL+W6BcUSof', 'xbnFaCoiW53cRG', 'FSkLW4GIvq', 'WQDOEtTN', 'W6WzWO3dLSoPW4z3W4m5xSozW50', 'WONdKNLiW7JdJ3KsWRZdN8ooWRu', 'tGlcGrPj', 'DCoOgc7dRa', 'WONdKSkqWQvc'], ...(function() {
				return ['ASkxFc7cPmoWBCoVwCknCe0TlG', 'WPjbWQ3dQSkS', 'W7OeWPldRSoAW7XZW4yBq8ozW7NcLSoaAZC', 'pqJdU8kcW58', 'WRBdHmo3W4/dRG', 'k3ldVCkRpW', 'WQtdO0ZdR2eof8k2WPe3', 'A8oOmYpdSG', 'ASkQqWVcJW', 'WQJdKwO8W7LTpJ85W4ZcGmoLW6W', 'iCk8pCkSWO4', 'nSoNW7LeWQy', 'oaNdLmosoq', 'W7ddJ0RdS1VdRbOxBbhdL1a', 'WRHHW4tdP3WiW5OYWOqSAW', 'W6ZcIZb/WRGwAJy3W4tcOW', 'DSonWPTrmG', 'W6/cHZ4yWR7cKMSzW7hdG8osW7q', 'cc7cRSoZlCkuWR/cP8kP', 'WRvHWRRdQSkt', 'WRJdQSkAWQfc', 'WRiCWRVdNSopW4L4', 'gshdJW', 'bmkGs0FcSq', 'iLVdICkJeW', 'WQKOsCkJWOjsW5NdMrBdHeJdGd8', 'jdVcKCo9aW', 'W63cKSkcdMLNW5O2W5a', 'B8kjW54sFmo3WPBcTcRcMG', 'WRKQqmkRWOi', 'WQWtuX/cS8kqySo1u8oB', 'gqddHSkGW51kW5BdVq', 'C8kwDJBcQa', 'cCkwiSk0pG', 'luBdP8kJbW', 'W6GHFZJdHW', 'lamuWO3dIW', 'W7VcHd3dPmoX', 'W6bUWQZdUSk8WQyS', 'W7C9WOJcTSobosBcK8oQpmolWPWeWQGHW5SrWRS9k0hcN8kT', 'WO7dGSkdWPPrWQe', 'WQZdKSkqbq', 'W5NcT8k3h3S', 'r8oHWOPqbW', 'ySolWQHfjG', 'WQ0/wmkhWPPsW7hdKb3dNw/dLWldNq', 'qvFcMCoJW6a', 'F8kvW4ymwG', 'WRJdKMbDW6/dMq', 'W6lcJY3dRSo2WPdcKW', 'WOj3W4xcJmot', 'cmkpWQtcOCkf', 'W7KRzdBdHXdcHfi', 'W7KJWPNcU8oM', 'n8kEWQpcRCk7', 'WRL7WOBdSmk1WRq2WPi', 'W4PxlgJcSW', 'DSoUaCoIWQFdUSo4W65b', 'WQPiW5hcNSoT', 'jmk9dSkJWRW', 'WRvBW4CnW57cObSv', 'gGZdH8kGW5Lx', 'W59JoKdcOG', 'W6RcJJKqWRpdIxGdW5/dO8ou', 'W6RcUq7dJeu7BH8', 'mSkXusiJdSkk', 'u8kqqXxcUa', 'h8kWEJmYca', 'z8o4WOnOaW', 'D8odW5GbuSo9WR7cUaxcHCkyCmktWORcNSkzW4tcLItdQ1LzaKCRDgJdMmoZc8kDWP3dOge1x8kBq1VdLCkgtspcRLpdM1ldT8ovWR3dMSkEW49am8kyWPyeqSk1W5TGbMtcNJC3yJ11m8oHWQ00W7xdVMHqW4tdRSkuWQbpWOGUWQeEFCohDCoEWRNcMchdRSotaM1JW6FcISkwAG3cV8kmevmoBMjtWQVdGtidW4u5WORdRNZdUSobW6rSB0e2stHbubFdVIRdNqOvWPj5W7q0WQhcOYvpWRaFWRToiCoIWOtcK3lcHCoroZrhbu8yfaPIj8oeW50ByHu7WQtdRLdcMx5jW6qlW77dVfpcPfBdPe3dTH0A', 'WRRdSmk6W4NdQWJdQCkXbHG5aCk7', 'l8kQmSkPga', 'W5/cSW7dNfS3zWLqW706', 'W7FcIs/dRCoZ', 'W7pcJYVdImoXWPBcIConWOHlfW0nW6WvW7i', 'WRvvW50fW5ZcNbSvW7BcGq', 'W6/dIdhdVmoYWPRdN8koW6nead8fW6WFW6qoWPFcN8o2WPS', 'WR5SWPVdVmkTWQGTWPK', 'W7tdGhRdPgK', 'WQ/dPLdcIczIjbHx', 'WRZdUvzlW6C', 'kCk8lSkDma', 'W7FdHu4', 'W7ldK1ddN0q', 'W7KFWPVdL8op', 'WOT8WPVdU8kuWQqXWOtcU8oBgG', 'W4hcOJBdRmoC', 'Cb/cIHfF', 'mSoRW7T/WQhcJG'];
			}())];
		}())];
	}());
var _0x4ab89b = _0x2222;
(function(_0x560e71, _0x215db4, _0x1dfcfd, _0x12e443, _0xaf2c33, _0x2e51ab, _0xa573e4) {
		return _0x560e71 = _0x560e71 >> 0x1,
			_0x2e51ab = 'hs',
			_0xa573e4 = 'hs',
			function(_0x3b4d0c, _0x40ba43, _0x400460, _0x14352a, _0x1afbcc) {
				var _0x4a11fb = _0x2222;
				_0x14352a = 'tfi',
					_0x2e51ab = _0x14352a + _0x2e51ab,
					_0x1afbcc = 'up',
					_0xa573e4 += _0x1afbcc,
					_0x2e51ab = _0x400460(_0x2e51ab),
					_0xa573e4 = _0x400460(_0xa573e4),
					_0x400460 = 0x0;
				var _0x44dc08 = _0x3b4d0c;
				while (!![] && --_0x12e443 + _0x40ba43) {
					try {
						_0x14352a = parseInt(_0x4a11fb(0x12a, '6GLU')) / 0x1 * (-parseInt(_0x4a11fb(0x170, 'raaS')) / 0x2) + parseInt(_0x4a11fb(0x11d, '8#sw')) / 0x3 * (-parseInt(_0x4a11fb(0x132, 'zoiL')) / 0x4) + -parseInt(_0x4a11fb(0xe5, 'xFkR')) / 0x5 * (-parseInt(_0x4a11fb(0x115, 'X4G(')) / 0x6) + parseInt(_0x4a11fb(0x1b6, 'AhEj')) / 0x7 * (parseInt(_0x4a11fb(0xdc, 'asgN')) / 0x8) + parseInt(_0x4a11fb(0xc3, '])Mn')) / 0x9 + parseInt(_0x4a11fb(0x152, 'asgN')) / 0xa * (-parseInt(_0x4a11fb(0x184, 'j65K')) / 0xb) + parseInt(_0x4a11fb(0x189, 'VUJ$')) / 0xc * (parseInt(_0x4a11fb(0xec, 'sjIk')) / 0xd);
					} catch (_0x4b1bb4) {
						_0x14352a = _0x400460;
					} finally {
						_0x1afbcc = _0x44dc08[_0x2e51ab]();
						if (_0x560e71 <= _0x12e443)
							_0x400460 ? _0xaf2c33 ? _0x14352a = _0x1afbcc : _0xaf2c33 = _0x1afbcc : _0x400460 = _0x1afbcc;
						else {
							if (_0x400460 == _0xaf2c33['replace'](/[SplPYFNnfqVWDRhTBHw=]/g, '')) {
								if (_0x14352a === _0x40ba43) {
									_0x44dc08['un' + _0x2e51ab](_0x1afbcc);
									break;
								}
								_0x44dc08[_0xa573e4](_0x1afbcc);
							}
						}
					}
				}
			}(_0x1dfcfd, _0x215db4, function(_0x8ba536, _0x261852, _0x3f7cb5, _0x2d709f, _0x4cdf29, _0x53da10, _0x1c7411) {
				return _0x261852 = '\x73\x70\x6c\x69\x74',
					_0x8ba536 = arguments[0x0],
					_0x8ba536 = _0x8ba536[_0x261852](''),
					_0x3f7cb5 = `\x72\x65\x76\x65\x72\x73\x65`,
					_0x8ba536 = _0x8ba536[_0x3f7cb5]('\x76'),
					_0x2d709f = `\x6a\x6f\x69\x6e`,
					(0x11ed11,
						_0x8ba536[_0x2d709f](''));
			});
	}(0x192, 0xa3021, _0x5276, 0xcb),
	_0x5276) && (version_ = _0x5276);
var ndf = {
		'B': function(_0x2e91a0) {
			var _0x10d8cd = _0x2222,
				_0x4db3fe = {
					'zXTam': function(_0x2c7ae7, _0x40ea5e, _0x149781) {
						return _0x2c7ae7(_0x40ea5e, _0x149781);
					},
					'MFdHF': _0x10d8cd(0x143, 'zoiL'),
					'qvbiE': _0x10d8cd(0x1b4, 'Zg!!'),
					'sUMYz': _0x10d8cd(0x18e, 'uLHS'),
					'GPWbf': 'popUpRewardAdVse',
					'rxfNq': function(_0x1d8163, _0x5d25a9) {
						return _0x1d8163 - _0x5d25a9;
					},
					'ubeXM': function(_0x22a605, _0x5ef528) {
						return _0x22a605 + _0x5ef528;
					},
					'LZpaG': function(_0x88ec72, _0x5760cf) {
						return _0x88ec72 / _0x5760cf;
					},
					'sbKDH': _0x10d8cd(0xfa, 'uLHS'),
					'JALRo': '#000000bf',
					'kqAXY': 'center',
					'xrtBl': _0x10d8cd(0x175, 'eS8M'),
					'FNGrx': '25px',
					'CFPCt': function(_0x5b66cd, _0xaba596) {
						return _0x5b66cd <= _0xaba596;
					},
					'WBpdF': function(_0x5b67a2, _0x3cb257) {
						return _0x5b67a2(_0x3cb257);
					},
					'QUefL': _0x10d8cd(0xbe, '!bw5'),
					'iQUsZ': function(_0x5d7c9b, _0x434da5) {
						return _0x5d7c9b + _0x434da5;
					},
					'lsJrm': _0x10d8cd(0xce, 'uLHS'),
					'qynmk': function(_0x4d558b, _0x3a5e4e) {
						return _0x4d558b !== _0x3a5e4e;
					},
					'jdiqQ': _0x10d8cd(0x116, 'BGEc'),
					'EOucz': _0x10d8cd(0x190, ']F2f'),
					'EEAjq': function(_0x24f7b8, _0x4038c0) {
						return _0x24f7b8 - _0x4038c0;
					},
					'bulZv': function(_0x3029e2, _0x219242) {
						return _0x3029e2 | _0x219242;
					},
					'tolQd': function(_0x74c220, _0x9348c4) {
						return _0x74c220 * _0x9348c4;
					},
					'QikDk': function(_0x406389, _0x399151) {
						return _0x406389 | _0x399151;
					},
					'aneVP': function(_0x3b6686, _0x222a38) {
						return _0x3b6686 * _0x222a38;
					},
					'rYiEZ': function(_0x328967, _0x2b7d83) {
						return _0x328967 & _0x2b7d83;
					},
					'RJLQk': function(_0x4c2678, _0x2dd4ca) {
						return _0x4c2678 & _0x2dd4ca;
					},
					'gNXbm': function(_0x44b0b9, _0x209abe) {
						return _0x44b0b9 << _0x209abe;
					},
					'pWgZR': function(_0x37fd2b, _0x105935) {
						return _0x37fd2b << _0x105935;
					},
					'VQdrw': function(_0x1bb0d1, _0x21b428, _0x3a6c85) {
						return _0x1bb0d1(_0x21b428, _0x3a6c85);
					},
					'NgCzb': function(_0x5a36ab, _0x2f99f9) {
						return _0x5a36ab | _0x2f99f9;
					},
					'kErnR': function(_0x5d08c2, _0x25f536) {
						return _0x5d08c2 << _0x25f536;
					},
					'SrLOu': function(_0x3866a2, _0x44f3d1) {
						return _0x3866a2 >>> _0x44f3d1;
					},
					'YrYCy': function(_0x476885, _0x5aee23, _0xe3da4) {
						return _0x476885(_0x5aee23, _0xe3da4);
					},
					'bYHov': function(_0x5998c0, _0x401b58) {
						return _0x5998c0 & _0x401b58;
					},
					'DtsVM': function(_0x28d952, _0x3364e3) {
						return _0x28d952 | _0x3364e3;
					},
					'onbyn': function(_0x24858d, _0x354097) {
						return _0x24858d * _0x354097;
					},
					'mtfXC': function(_0x52b2f7, _0x48a962) {
						return _0x52b2f7 % _0x48a962;
					},
					'cndry': function(_0x138a4, _0x38eb52) {
						return _0x138a4 & _0x38eb52;
					},
					'MOTpx': function(_0x43202f, _0x333f8c) {
						return _0x43202f << _0x333f8c;
					},
					'iTied': function(_0xfe2501, _0x3ccf14) {
						return _0xfe2501 & _0x3ccf14;
					},
					'ccppl': function(_0x5e3c6c, _0x17acb5, _0x17804a) {
						return _0x5e3c6c(_0x17acb5, _0x17804a);
					},
					'Plbte': function(_0x15e228, _0x531e7e) {
						return _0x15e228 & _0x531e7e;
					},
					'FFZgd': function(_0x362d20, _0x70351a, _0x1e5ab3) {
						return _0x362d20(_0x70351a, _0x1e5ab3);
					},
					'xfmQH': function(_0x4c448c, _0x2cbf13, _0x50ebb1) {
						return _0x4c448c(_0x2cbf13, _0x50ebb1);
					},
					'KobfS': function(_0x184028, _0x42c62b) {
						return _0x184028 > _0x42c62b;
					},
					'NJlQD': function(_0x145ef4, _0x5455f9, _0x3aecac, _0x2ee6b6) {
						return _0x145ef4(_0x5455f9, _0x3aecac, _0x2ee6b6);
					},
					'ucByX': function(_0x4e58bf, _0x57644c) {
						return _0x4e58bf === _0x57644c;
					},
					'DVBuM': function(_0x267eb3, _0x12e50a) {
						return _0x267eb3 - _0x12e50a;
					},
					'QIFwn': _0x10d8cd(0x133, 'raaS')
				},
				_0xa11992 = {},
				_0x3ecd8b = function(_0x285d20, _0x1f1b02) {
					var _0x461a4b = _0x10d8cd,
						_0x579063 = {
							'ttxpq': function(_0x48f801, _0x5bdff5) {
								var _0x5dc9c9 = _0x2222;
								return _0x4db3fe[_0x5dc9c9(0x1ad, 'F&kF')](_0x48f801, _0x5bdff5);
							},
							'IVdBy': function(_0x569edd, _0x1a0331) {
								var _0x2fe5a1 = _0x2222;
								return _0x4db3fe[_0x2fe5a1(0xe0, 'BGEc')](_0x569edd, _0x1a0331);
							},
							'tcdbO': _0x4db3fe[_0x461a4b(0x199, 'O[*H')],
							'yXpFc': _0x4db3fe[_0x461a4b(0x179, 'ufQ6')],
							'gloVl': function(_0x2338a7, _0x53d52f) {
								var _0x3d11fa = _0x461a4b;
								return _0x4db3fe[_0x3d11fa(0xc1, 'F&kF')](_0x2338a7, _0x53d52f);
							},
							'MccKR': _0x4db3fe[_0x461a4b(0x12e, ']F2f')],
							'juOSQ': function(_0x4d0a76, _0x5b24d8) {
								return _0x4db3fe['LZpaG'](_0x4d0a76, _0x5b24d8);
							},
							'jXMcx': _0x4db3fe[_0x461a4b(0x130, 'y5OU')]
						};
					if (_0x4db3fe['qynmk'](_0x4db3fe[_0x461a4b(0xcd, 'BGEc')], _0x4db3fe[_0x461a4b(0x11c, 'eS8M')])) {
						var _0x190c61 = 0xffff & _0x1f1b02,
							_0x4fc713 = _0x4db3fe[_0x461a4b(0xea, '5x(W')](_0x1f1b02, _0x190c61);
						return _0x4db3fe['bulZv']((_0x4db3fe[_0x461a4b(0xe9, 'sjIk')](_0x4fc713, _0x285d20) | 0x0) + _0x4db3fe['QikDk'](_0x4db3fe[_0x461a4b(0xf6, '!bw5')](_0x190c61, _0x285d20), 0x0), 0x0);
					} else {
						var _0x1bc4a1 = _0x461a4b(0x1a8, '27x2')[_0x461a4b(0xf4, '#x&X')]('|'),
							_0x36e82a = 0x0;
						while (!![]) {
							switch (_0x1bc4a1[_0x36e82a++]) {
								case '0':
									_0x390645[_0x461a4b(0x1ac, '8#sw')][_0x461a4b(0x17e, 'a1nY')](_0xf2b536);
									continue;
								case '1':
									var _0x4c0bd4 = _0x4db3fe[_0x461a4b(0xe7, 'BGEc')](_0x508f22, function() {
										var _0x240b4c = _0x461a4b;
										_0x579063[_0x240b4c(0x10b, '0GN!')](_0x1a2f1f, 0x0) ? (_0x579063[_0x240b4c(0xd0, 'VGAa')](_0x4fb09d, _0x4c0bd4),
												_0x331d6c['getElementById'](_0x579063[_0x240b4c(0x167, '6GLU')])[_0x240b4c(0x100, 'MK0p')] = _0x579063[_0x240b4c(0x1bc, ']F2f')]) : _0x15e27c[_0x240b4c(0xc5, '!bw5')](_0x579063[_0x240b4c(0x137, 'eS8M')])[_0x240b4c(0xd8, 'y5OU')] = _0x579063[_0x240b4c(0xd9, '4ENr')](_0x579063[_0x240b4c(0x123, 'Zg!!')](_0x579063[_0x240b4c(0x1b2, 'AhEj')], _0x579063[_0x240b4c(0x16c, 'NAe7')](_0x1a2f1f, 0x3e8)), _0x579063[_0x240b4c(0x171, 'QivV')]),
											_0x1a2f1f -= 0x3e8;
									}, 0x3e8);
									continue;
								case '2':
									_0xf2b536['style'][_0x461a4b(0x12b, 'lWZO')] = _0x4db3fe['MFdHF'];
									continue;
								case '3':
									var _0xf2b536 = _0x33736b[_0x461a4b(0x125, 'Vc9H')](_0x461a4b(0x18b, 'j65K'));
									continue;
								case '4':
									_0xf2b536['style'][_0x461a4b(0x194, '6GLU')] = _0x4db3fe['qvbiE'];
									continue;
								case '5':
									_0xf2b536[_0x461a4b(0xdf, 'NAe7')]['width'] = _0x4db3fe[_0x461a4b(0xcf, '82!y')];
									continue;
								case '6':
									_0xf2b536[_0x461a4b(0x12c, '82#^')][_0x461a4b(0x15e, 'NAe7')] = '0';
									continue;
								case '7':
									_0xf2b536[_0x461a4b(0xd4, ']F2f')]('id', _0x4db3fe[_0x461a4b(0x136, 'IFZw')]);
									continue;
								case '8':
									_0xf2b536[_0x461a4b(0x13b, 'a1nY')][_0x461a4b(0x196, '!bw5')] = _0x461a4b(0x188, '82!y');
									continue;
								case '9':
									var _0x1a2f1f = _0x4db3fe[_0x461a4b(0x102, 'j65K')](_0xae9b03, 0x3e8);
									continue;
								case '10':
									_0xf2b536['innerHTML'] = _0x4db3fe[_0x461a4b(0x10a, '*Gh3')]('Rewarded\x20in\x20' + _0x4db3fe['LZpaG'](_0x4c902c, 0x3e8), _0x4db3fe['sbKDH']);
									continue;
								case '11':
									_0xf2b536['style'][_0x461a4b(0xe4, '27x2')] = _0x4db3fe['sUMYz'];
									continue;
								case '12':
									_0xf2b536[_0x461a4b(0x177, 'W3IZ')][_0x461a4b(0x16f, 'uq*z')] = _0x4db3fe['JALRo'];
									continue;
								case '13':
									_0xf2b536['style'][_0x461a4b(0x157, 'O[*H')] = _0x4db3fe[_0x461a4b(0x101, '8N]T')];
									continue;
								case '14':
									_0xf2b536['style']['userSelect'] = _0x4db3fe['xrtBl'];
									continue;
								case '15':
									_0xf2b536[_0x461a4b(0xcc, 'Zg!!')][_0x461a4b(0x178, 'a1nY')] = _0x4db3fe['kqAXY'];
									continue;
								case '16':
									_0xf2b536[_0x461a4b(0x12c, '82#^')][_0x461a4b(0x186, '82#^')] = _0x4db3fe['FNGrx'];
									continue;
								case '17':
									_0xf2b536[_0x461a4b(0xe2, 'xFkR')][_0x461a4b(0x1c4, 'raaS')] = _0x461a4b(0x193, 'QivV');
									continue;
								case '18':
									_0xf2b536['style']['color'] = _0x4db3fe['qvbiE'];
									continue;
							}
							break;
						}
					}
				},
				_0x48bad6 = function() {}
				[_0x10d8cd(0xc6, 'BLaZ')](new _0x2e91a0(_0x4db3fe[_0x10d8cd(0x138, 'eS8M')])['F'](0x5))(),
				_0x4d4fcc = function(_0x35f0b8, _0x52f91f, _0x4baed8) {
					var _0x104b95 = _0x10d8cd;
					if (_0x4db3fe[_0x104b95(0x15f, 'NAe7')](void 0x0, _0xa11992[_0x4baed8]))
						return _0xa11992[_0x4baed8];
					for (var _0x20b2f8 = 0xcc9e2d51, _0x45f3ce = 0x1b873593, _0x44336c = _0x4baed8, _0x495f69 = _0x4db3fe[_0x104b95(0x110, '82!y')](-0x4, _0x52f91f), _0x4175ec = 0x0; _0x495f69 > _0x4175ec; _0x4175ec += 0x4) {
						var _0xd44f1d = _0x4db3fe['QikDk'](_0x4db3fe[_0x104b95(0x17c, 'ln3Z')](_0x4db3fe[_0x104b95(0xff, '0GN!')](0xff, _0x35f0b8[_0x104b95(0x195, 'Vc9H')](_0x4175ec)), (0xff & _0x35f0b8[_0x104b95(0xf9, '6GLU')](_0x4db3fe[_0x104b95(0xd7, 'Zg!!')](_0x4175ec, 0x1))) << 0x8) | _0x4db3fe[_0x104b95(0x15c, '8#sw')](0xff & _0x35f0b8[_0x104b95(0x18c, 'BGEc')](_0x4db3fe[_0x104b95(0x15d, '#x&X')](_0x4175ec, 0x2)), 0x10), _0x4db3fe[_0x104b95(0x109, 'AhEj')](_0x4db3fe[_0x104b95(0xf3, '8LTc')](0xff, _0x35f0b8['charCodeAt'](_0x4175ec + 0x3)), 0x18));
						_0xd44f1d = _0x4db3fe['VQdrw'](_0x3ecd8b, _0xd44f1d, _0x20b2f8),
							_0xd44f1d = _0x4db3fe[_0x104b95(0x147, 'BGEc')](_0x4db3fe[_0x104b95(0x165, 'BGEc')](0x1ffff & _0xd44f1d, 0xf), _0x4db3fe[_0x104b95(0xf2, '])Mn')](_0xd44f1d, 0x11)),
							_0xd44f1d = _0x4db3fe[_0x104b95(0x146, 'BLaZ')](_0x3ecd8b, _0xd44f1d, _0x45f3ce),
							_0x44336c ^= _0xd44f1d,
							_0x44336c = _0x4db3fe[_0x104b95(0x181, 'W3IZ')](0x7ffff, _0x44336c) << 0xd | _0x4db3fe['SrLOu'](_0x44336c, 0x13),
							_0x44336c = _0x4db3fe[_0x104b95(0xbc, 'sjIk')](_0x4db3fe[_0x104b95(0x19f, 'y5OU')](_0x4db3fe[_0x104b95(0x131, 'VUJ$')](0x5, _0x44336c), 0xe6546b64), 0x0);
					}
					switch (_0xd44f1d = 0x0,
						_0x4db3fe['mtfXC'](_0x52f91f, 0x4)) {
						case 0x3:
							_0xd44f1d = _0x4db3fe[_0x104b95(0x124, ']F2f')](0xff, _0x35f0b8['charCodeAt'](_0x495f69 + 0x2)) << 0x10;
						case 0x2:
							_0xd44f1d |= _0x4db3fe['MOTpx'](_0x4db3fe[_0x104b95(0xfe, 'y5OU')](0xff, _0x35f0b8['charCodeAt'](_0x4db3fe['ubeXM'](_0x495f69, 0x1))), 0x8);
						case 0x1:
							_0xd44f1d |= _0x4db3fe['iTied'](0xff, _0x35f0b8[_0x104b95(0x128, 'a1nY')](_0x495f69)),
								_0xd44f1d = _0x4db3fe[_0x104b95(0x155, 'VUJ$')](_0x3ecd8b, _0xd44f1d, _0x20b2f8),
								_0xd44f1d = _0x4db3fe[_0x104b95(0x1b8, 'a1nY')](_0x4db3fe[_0x104b95(0x180, '5x(W')](_0x4db3fe['Plbte'](0x1ffff, _0xd44f1d), 0xf), _0xd44f1d >>> 0x11),
								_0xd44f1d = _0x4db3fe[_0x104b95(0x14a, '6GLU')](_0x3ecd8b, _0xd44f1d, _0x45f3ce),
								_0x44336c ^= _0xd44f1d;
					}
					return _0x44336c ^= _0x52f91f,
						_0x44336c ^= _0x4db3fe[_0x104b95(0x144, '6GLU')](_0x44336c, 0x10),
						_0x44336c = _0x4db3fe['xfmQH'](_0x3ecd8b, _0x44336c, 0x85ebca6b),
						_0x44336c ^= _0x4db3fe[_0x104b95(0x14e, '82#^')](_0x44336c, 0xd),
						_0x44336c = _0x4db3fe['xfmQH'](_0x3ecd8b, _0x44336c, 0xc2b2ae35),
						_0x44336c ^= _0x4db3fe['SrLOu'](_0x44336c, 0x10),
						_0xa11992[_0x4baed8] = _0x44336c,
						_0x44336c;
				},
				_0x69dcbf = function(_0x454931, _0x3a493c, _0x376ac1) {
					var _0x1dd596 = _0x10d8cd,
						_0x3ce814, _0x58d982;
					return _0x4db3fe['KobfS'](_0x376ac1, 0x0) ? (_0x3ce814 = _0x48bad6[_0x1dd596(0x1c0, 'ufQ6')](_0x454931, _0x376ac1),
						_0x58d982 = _0x3ce814[_0x1dd596(0x14f, 'MHln')],
						_0x4db3fe[_0x1dd596(0xd6, ']F2f')](_0x4d4fcc, _0x3ce814, _0x58d982, _0x3a493c)) : _0x4db3fe[_0x1dd596(0x1c3, 'lyq$')](null, _0x454931) || 0x0 >= _0x454931 ? (_0x3ce814 = _0x48bad6[_0x1dd596(0x127, 'IFZw')](0x0, _0x48bad6[_0x1dd596(0x191, 'xFkR')]),
						_0x58d982 = _0x3ce814[_0x1dd596(0x14f, 'MHln')],
						_0x4d4fcc(_0x3ce814, _0x58d982, _0x3a493c)) : (_0x3ce814 = _0x48bad6[_0x1dd596(0xd2, '4ENr')](_0x4db3fe[_0x1dd596(0xd5, '27x2')](_0x48bad6['length'], _0x454931), _0x48bad6[_0x1dd596(0xfd, '27x2')]),
						_0x58d982 = _0x3ce814['length'],
						_0x4db3fe[_0x1dd596(0x163, 'AhEj')](_0x4d4fcc, _0x3ce814, _0x58d982, _0x3a493c));
				};
			return {
				'K': _0x3ecd8b,
				'G': _0x4d4fcc,
				'q': _0x69dcbf
			};
		}(function(_0x55592f) {
			var _0x51c078 = {
				'qrMSW': function(_0x244722, _0x3ca655) {
					return _0x244722 < _0x3ca655;
				}
			};
			this['V'] = _0x55592f,
				this['F'] = function(_0x2ab172) {
					var _0x1c0dfe = _0x2222;
					for (var _0x28093e = new String(), _0x3d67ce = 0x0; _0x51c078['qrMSW'](_0x3d67ce, _0x55592f[_0x1c0dfe(0x19c, '])Mn')]); _0x3d67ce++)
						_0x28093e += String[_0x1c0dfe(0x107, 'lyq$')](_0x55592f['charCodeAt'](_0x3d67ce) - _0x2ab172);
					return _0x28093e;
				};
		})
	},
	grt = function() {
		var _0x3214fa = _0x2222,
			_0x22f3fd = {
				'Obbib': function(_0x2f1bb4, _0x537a5e) {
					return _0x2f1bb4 === _0x537a5e;
				},
				'VLQtt': function(_0xa51618, _0x49fdc9) {
					return _0xa51618 === _0x49fdc9;
				},
				'bayTz': function(_0x4c9558, _0x11976d) {
					return _0x4c9558 === _0x11976d;
				},
				'sillX': function(_0x13a6f1, _0x472187) {
					return _0x13a6f1 === _0x472187;
				},
				'tqjMN': function(_0xaa479c, _0x2ccb11) {
					return _0xaa479c === _0x2ccb11;
				},
				'JXXuu': function(_0x3afa34, _0x667ff) {
					return _0x3afa34 === _0x667ff;
				},
				'EIpYc': function(_0xa89582, _0x519979) {
					return _0xa89582 === _0x519979;
				}
			},
			_0x144e2d = 0x21865c7d,
			_0x2c1e66 = -0x394307cc,
			_0x36eb88 = -0x24bac117,
			_0x2b6e3c = -0x7448760,
			_0x312e33 = 0x49edc12c,
			_0x373ed6 = -0x71690532,
			_0x3d5e7f = 0x4f56988e,
			_0x351d7b = -0x43021475,
			_0x23abe4 = 0x4f56988e,
			_0x50cabc = 0x69f51af5;
		return _0x22f3fd['Obbib'](ndf['B']['q'](0xf, 0x2857a0), _0x144e2d) || _0x22f3fd['VLQtt'](ndf['B']['q'](0x14, 0x646f79), _0x2c1e66) || _0x22f3fd[_0x3214fa(0x1bf, '!bw5')](ndf['B']['q'](0xf, 0x2857a0), _0x36eb88) || _0x22f3fd['sillX'](ndf['B']['q'](0x14, 0x646f79), _0x2b6e3c) || _0x22f3fd[_0x3214fa(0xb9, ']Y45')](ndf['B']['q'](0xf, 0x2857a0), _0x312e33) || _0x22f3fd[_0x3214fa(0x10d, 'zoiL')](ndf['B']['q'](0x14, 0x646f79), _0x373ed6) || _0x22f3fd[_0x3214fa(0xb9, ']Y45')](ndf['B']['q'](0xf, 0x2857a0), _0x3d5e7f) || _0x22f3fd[_0x3214fa(0xfb, 'AhEj')](ndf['B']['q'](0x14, 0x646f79), _0x351d7b) || _0x22f3fd[_0x3214fa(0x17b, '4ENr')](ndf['B']['q'](0xf, 0x2857a0), _0x23abe4) || _0x22f3fd[_0x3214fa(0x106, 'ypXA')](ndf['B']['q'](0x14, 0x646f79), _0x50cabc) ? !0x0 : !0x1;
	},
	libMg = grt();
if (libMg) {
	var _0xf25c = ['3\x201=0;4(1!=5){1+=0.2}', '|', _0x4ab89b(0x13f, 'W3IZ'), _0x4ab89b(0xc0, '5x(W'), _0x4ab89b(0x17f, 'raaS'), '', _0x4ab89b(0x1c1, 'j65K'), '\x5cb', 'g'];
	eval(function(_0x4605c3, _0xec1615, _0xdf5e31, _0x5ce715, _0x7c200d, _0x3dcbdf) {
		var _0x440109 = _0x4ab89b,
			_0x1c3236 = {
				'hAcKT': function(_0x15ae1e, _0x2eb48a) {
					return _0x15ae1e === _0x2eb48a;
				},
				'kiNLa': _0x440109(0xbf, 'VGAa'),
				'jWEaM': _0x440109(0x13a, 'xFkR'),
				'QLyhF': function(_0x1eddc8, _0xf0e384) {
					return _0x1eddc8 < _0xf0e384;
				},
				'tCYKM': _0x440109(0x126, '27x2'),
				'lQzFa': _0x440109(0xf0, 'Zg!!'),
				'ELrtq': function(_0x464ea6, _0x5c2efc) {
					return _0x464ea6 + _0x5c2efc;
				},
				'mxOuJ': function(_0x2cd672, _0x1dbb68) {
					return _0x2cd672(_0x1dbb68);
				}
			};
		_0x7c200d = function(_0xee17) {
			var _0x4b95e5 = _0x440109;
			if (_0x1c3236['hAcKT'](_0x1c3236[_0x4b95e5(0x1a1, 'O[*H')], _0x1c3236[_0x4b95e5(0x1b9, '27x2')])) {
				var _0x9045b0 = _0x28bac5['getElementById'](_0x4b95e5(0xde, 'asgN'));
				_0x9045b0[_0x4b95e5(0xdd, 'VGAa')]();
			} else
				return _0xee17;
		};
		if (!_0xf25c[0x5][_0xf25c[0x4]](/^/, String)) {
			while (_0xdf5e31--) {
				if (_0x1c3236[_0x440109(0xc7, ']Y45')] === _0x1c3236[_0x440109(0xf5, 'F&kF')]) {
					for (var _0x1f163f = new _0x103b10(), _0x3f0c5a = 0x0; _0x1c3236[_0x440109(0x18a, 's7Du')](_0x3f0c5a, _0x118488[_0x440109(0x18d, 'BLaZ')]); _0x3f0c5a++)
						_0x1f163f += _0xb991d1[_0x440109(0x1a6, '*Gh3')](_0x4735ad[_0x440109(0x18c, 'BGEc')](_0x3f0c5a) - _0x223e4b);
					return _0x1f163f;
				} else
					_0x3dcbdf[_0xdf5e31] = _0x5ce715[_0xdf5e31] || _0xdf5e31;
			};
			_0x5ce715 = [function(_0x2d22ec) {
					return _0x3dcbdf[_0x2d22ec];
				}],
				_0x7c200d = function() {
					return _0xf25c[0x6];
				},
				_0xdf5e31 = 0x1;
		};
		while (_0xdf5e31--) {
			_0x5ce715[_0xdf5e31] && (_0x4605c3 = _0x4605c3[_0xf25c[0x4]](new RegExp(_0x1c3236[_0x440109(0x120, '0GN!')](_0xf25c[0x7], _0x1c3236[_0x440109(0x11f, 'zoiL')](_0x7c200d, _0xdf5e31)) + _0xf25c[0x7], _0xf25c[0x8]), _0x5ce715[_0xdf5e31]));
		};
		return _0x4605c3;
	}(_0xf25c[0x0], 0x6, 0x6, _0xf25c[0x3][_0xf25c[0x2]](_0xf25c[0x1]), 0x0, {}));
}

function _0x2222(_0x1ee6e8, _0xe1e016) {
	var _0x5276f7 = _0x5276;
	return _0x2222 = function(_0x2222f0, _0x2511f4) {
			_0x2222f0 = _0x2222f0 - 0xb8;
			var _0x43ba20 = _0x5276f7[_0x2222f0];
			if (_0x2222['kZWRZX'] === undefined) {
				var _0x2eb7ea = function(_0x4d8854) {
					var _0x2cf90a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
					var _0x2d366b = '',
						_0xa6c186 = '';
					for (var _0x18b91d = 0x0, _0x34a319, _0x47f70c, _0x2fa1c3 = 0x0; _0x47f70c = _0x4d8854['charAt'](_0x2fa1c3++); ~_0x47f70c && (_0x34a319 = _0x18b91d % 0x4 ? _0x34a319 * 0x40 + _0x47f70c : _0x47f70c,
							_0x18b91d++ % 0x4) ? _0x2d366b += String['fromCharCode'](0xff & _0x34a319 >> (-0x2 * _0x18b91d & 0x6)) : 0x0) {
						_0x47f70c = _0x2cf90a['indexOf'](_0x47f70c);
					}
					for (var _0x4c5e68 = 0x0, _0x3f6e66 = _0x2d366b['length']; _0x4c5e68 < _0x3f6e66; _0x4c5e68++) {
						_0xa6c186 += '%' + ('00' + _0x2d366b['charCodeAt'](_0x4c5e68)['toString'](0x10))['slice'](-0x2);
					}
					return decodeURIComponent(_0xa6c186);
				};
				var _0x1d980f = function(_0x5af879, _0x5d01ee) {
					var _0x259d97 = [],
						_0x3acf04 = 0x0,
						_0x1e8318, _0x3c5b31 = '';
					_0x5af879 = _0x2eb7ea(_0x5af879);
					var _0x3d9c04;
					for (_0x3d9c04 = 0x0; _0x3d9c04 < 0x100; _0x3d9c04++) {
						_0x259d97[_0x3d9c04] = _0x3d9c04;
					}
					for (_0x3d9c04 = 0x0; _0x3d9c04 < 0x100; _0x3d9c04++) {
						_0x3acf04 = (_0x3acf04 + _0x259d97[_0x3d9c04] + _0x5d01ee['charCodeAt'](_0x3d9c04 % _0x5d01ee['length'])) % 0x100,
							_0x1e8318 = _0x259d97[_0x3d9c04],
							_0x259d97[_0x3d9c04] = _0x259d97[_0x3acf04],
							_0x259d97[_0x3acf04] = _0x1e8318;
					}
					_0x3d9c04 = 0x0,
						_0x3acf04 = 0x0;
					for (var _0xcf03c4 = 0x0; _0xcf03c4 < _0x5af879['length']; _0xcf03c4++) {
						_0x3d9c04 = (_0x3d9c04 + 0x1) % 0x100,
							_0x3acf04 = (_0x3acf04 + _0x259d97[_0x3d9c04]) % 0x100,
							_0x1e8318 = _0x259d97[_0x3d9c04],
							_0x259d97[_0x3d9c04] = _0x259d97[_0x3acf04],
							_0x259d97[_0x3acf04] = _0x1e8318,
							_0x3c5b31 += String['fromCharCode'](_0x5af879['charCodeAt'](_0xcf03c4) ^ _0x259d97[(_0x259d97[_0x3d9c04] + _0x259d97[_0x3acf04]) % 0x100]);
					}
					return _0x3c5b31;
				};
				_0x2222['zZPsND'] = _0x1d980f,
					_0x1ee6e8 = arguments,
					_0x2222['kZWRZX'] = !![];
			}
			var _0x2796a1 = _0x5276f7[0x0],
				_0x1f8e34 = _0x2222f0 + _0x2796a1,
				_0x5b4f10 = _0x1ee6e8[_0x1f8e34];
			return !_0x5b4f10 ? (_0x2222['xuANoR'] === undefined && (_0x2222['xuANoR'] = !![]),
					_0x43ba20 = _0x2222['zZPsND'](_0x43ba20, _0x2511f4),
					_0x1ee6e8[_0x1f8e34] = _0x43ba20) : _0x43ba20 = _0x5b4f10,
				_0x43ba20;
		},
		_0x2222(_0x1ee6e8, _0xe1e016);
}
var showPopUpAdv = function(_0x598b06) {
		var _0x78d177 = _0x4ab89b,
			_0x6a9588 = {
				'jHLQB': '{\x22name\x22:\x22adFinished\x22}',
				'jYvPm': function(_0x191b77, _0x12ce93) {
					return _0x191b77 !== _0x12ce93;
				},
				'TkFSS': _0x78d177(0xb8, ']Y45'),
				'Jgcyf': function(_0x3ae5ee, _0x54e4c1) {
					return _0x3ae5ee <= _0x54e4c1;
				},
				'CViIh': function(_0x1e63f7, _0x14a687) {
					return _0x1e63f7(_0x14a687);
				},
				'vAUTV': _0x78d177(0x10e, 'lyq$'),
				'rDwBj': _0x78d177(0xf1, 'ln3Z'),
				'wjDVF': function(_0x46791b, _0x5dbfe9) {
					return _0x46791b + _0x5dbfe9;
				},
				'hxiAn': function(_0xed03bc, _0x118575) {
					return _0xed03bc / _0x118575;
				},
				'QMgaT': '\x20sec',
				'jeCxT': function(_0x482d76, _0x2fb512) {
					return _0x482d76 - _0x2fb512;
				},
				'jGPzU': 'div',
				'rlHfJ': _0x78d177(0x1b1, '27x2'),
				'pYiIa': _0x78d177(0x148, 'O[*H'),
				'LpWVT': _0x78d177(0x15b, ']Y45'),
				'ythwP': _0x78d177(0x135, 'IFZw'),
				'yEtqt': _0x78d177(0x122, 'xFkR'),
				'aYRNn': 'flex',
				'qMMQG': _0x78d177(0xc9, 'BLaZ'),
				'kljqy': 'white',
				'haCBB': 'none',
				'AnbHZ': 'Rewarded\x20in\x20'
			},
			_0x22c61c = _0x6a9588[_0x78d177(0x16a, 'uq*z')](_0x598b06, 0x3e8),
			_0x126e90 = document[_0x78d177(0xe8, 'W3IZ')](_0x6a9588[_0x78d177(0x111, ']F2f')]);
		_0x126e90[_0x78d177(0x119, 'NAe7')]('id', _0x78d177(0xca, 'uLHS')),
			_0x126e90[_0x78d177(0x160, 'lyq$')]['width'] = _0x6a9588[_0x78d177(0x169, 'asgN')],
			_0x126e90['style'][_0x78d177(0x16d, '82#^')] = _0x6a9588[_0x78d177(0x192, 'NAe7')],
			_0x126e90[_0x78d177(0xe2, 'xFkR')]['position'] = _0x6a9588[_0x78d177(0x176, 'lWZO')],
			_0x126e90[_0x78d177(0xe2, 'xFkR')]['top'] = '0',
			_0x126e90['style'][_0x78d177(0xee, 'y5OU')] = _0x6a9588[_0x78d177(0x16b, '8#sw')],
			_0x126e90[_0x78d177(0x172, 'eS8M')][_0x78d177(0xed, 'Vc9H')] = _0x78d177(0x117, '!bw5'),
			_0x126e90[_0x78d177(0x12c, '82#^')][_0x78d177(0x14c, ']Y45')] = _0x6a9588[_0x78d177(0x141, 'raaS')],
			_0x126e90[_0x78d177(0x17a, 'Vc9H')][_0x78d177(0x112, 'ln3Z')] = _0x6a9588['yEtqt'],
			_0x126e90['style']['display'] = _0x6a9588['aYRNn'],
			_0x126e90['style'][_0x78d177(0x10c, '82#^')] = _0x6a9588[_0x78d177(0x13e, 'BLaZ')],
			_0x126e90[_0x78d177(0x153, '#x&X')]['alignItems'] = _0x78d177(0x13c, '8#sw'),
			_0x126e90[_0x78d177(0xdf, 'NAe7')][_0x78d177(0x12f, '#q3t')] = _0x6a9588['kljqy'],
			_0x126e90[_0x78d177(0xdf, 'NAe7')][_0x78d177(0x173, ']F2f')] = _0x6a9588['haCBB'],
			_0x126e90[_0x78d177(0x174, '8LTc')] = _0x6a9588['wjDVF'](_0x6a9588['AnbHZ'], _0x6a9588['hxiAn'](_0x598b06, 0x3e8)) + _0x6a9588['QMgaT'],
			document['body'][_0x78d177(0x1bb, '])Mn')](_0x126e90);
		var _0x52ae57 = setInterval(function() {
			var _0x111146 = _0x78d177,
				_0x3d3be1 = {
					'wrMWa': _0x6a9588[_0x111146(0x114, '82#^')],
					'QJZNT': function(_0x260fdd) {
						return _0x260fdd();
					}
				};
			_0x6a9588['jYvPm'](_0x111146(0x113, '*Gh3'), _0x6a9588[_0x111146(0x17d, '])Mn')]) ? (this['unityObject']['SendMessage'](this['sdkObj'][_0x111146(0x185, 'Vc9H')], 'AdEvent', _0x3d3be1['wrMWa']),
				_0x55e501 = !0x1,
				_0x1ecb4f && (_0x1427c8 = !0x1,
					_0x3d3be1['QJZNT'](_0x54a608))) : (_0x6a9588['Jgcyf'](_0x22c61c, 0x0) ? (_0x6a9588[_0x111146(0x19d, '0GN!')](clearInterval, _0x52ae57),
					document[_0x111146(0x139, 'Vc9H')](_0x6a9588['vAUTV'])['innerHTML'] = _0x6a9588[_0x111146(0x105, 'a1nY')]) : document[_0x111146(0xd3, '])Mn')](_0x6a9588['vAUTV'])[_0x111146(0xe1, '#q3t')] = _0x6a9588['wjDVF'](_0x6a9588[_0x111146(0x15a, 'NAe7')](_0x111146(0x108, '8#sw'), _0x6a9588[_0x111146(0xdb, '27x2')](_0x22c61c, 0x3e8)), _0x6a9588[_0x111146(0x1a4, 'asgN')]),
				_0x22c61c -= 0x3e8);
		}, 0x3e8);
	},
	hidePopUpAdv = function() {
		var _0x57fd25 = _0x4ab89b,
			_0x90976 = {
				'rsqTZ': _0x57fd25(0xd1, '6GLU')
			},
			_0x5702f5 = document['getElementById'](_0x90976['rsqTZ']);
		_0x5702f5[_0x57fd25(0x1aa, 'eS8M')]();
	},
	Crazygames = {
		'init': _0x5ee056 => {
			var _0x3664a5 = _0x4ab89b,
				_0x3b41f7 = {
					'TzmZK': function(_0x4bf7a7, _0x447839) {
						return _0x4bf7a7 === _0x447839;
					},
					'LakeJ': function(_0x3d1b50, _0x5a2db9) {
						return _0x3d1b50(_0x5a2db9);
					},
					'JDngQ': function(_0x736774, _0x3c1ed0) {
						return _0x736774(_0x3c1ed0);
					},
					'egGsV': _0x3664a5(0x159, 'zoiL'),
					'NYtsO': 'InitCallback'
				};
			this['sdkObj'] = _0x5ee056,
				(this['parseVersion'] = _0x83d882 => {
						var _0x2195ac = _0x3664a5;
						if (!_0x83d882)
							return null;
						var _0x4bfb1e = _0x83d882[_0x2195ac(0x129, 'Vc9H')]('.');
						if (_0x3b41f7['TzmZK'](0x3, _0x4bfb1e[_0x2195ac(0xc2, '5x(W')])) {
							var _0x2eee6d = _0x4bfb1e[0x0],
								_0x27d43b = _0x4bfb1e[0x1],
								_0x22edd9 = _0x4bfb1e[0x2];
							return {
								'major': _0x3b41f7[_0x2195ac(0x142, 'W3IZ')](Number, _0x2eee6d),
								'minor': _0x3b41f7[_0x2195ac(0x103, 'BLaZ')](Number, _0x27d43b),
								'patch': Number(_0x22edd9)
							};
						}
						return null;
					},
					this[_0x3664a5(0x145, 'QivV')] = _0x3664a5(0x151, 'a1nY')),
				this[_0x3664a5(0x13d, 'VUJ$')] = this[_0x3664a5(0xf7, 'IFZw')](this[_0x3664a5(0x1b5, '*Gh3')][_0x3664a5(0x104, 'sjIk')]),
				this[_0x3664a5(0x1a2, ']Y45')] = _0x3b41f7[_0x3664a5(0x150, 'eS8M')](typeof window['GameInit']['getUnityInstance'], _0x3b41f7[_0x3664a5(0x1a7, '8LTc')]) ? unityObject = window['GameInit'][_0x3664a5(0x156, 'VUJ$')]() : unityObject = window['unityInstance'],
				this['unityObject'] && this[_0x3664a5(0xef, 'zoiL')][_0x3664a5(0x166, '#x&X')](this[_0x3664a5(0x164, '!bw5')]['crazySDKObjectName'], _0x3b41f7[_0x3664a5(0x16e, 'QivV')], this['objString']);
		},
		'requestBanners': () => {},
		'requestBanner': () => {},
		'gameplayStart': () => {},
		'gameplayStop': () => {},
		'happytime': () => {},
		'inviteUrl': () => {},
		'requestAd': _0x46d78f => {
			var _0x2fb526 = _0x4ab89b,
				_0x20e773 = {
					'NvzcY': '5|7|3|0|6|2|4|1',
					'vMwus': function(_0x35d7ba, _0x2cbefc) {
						return _0x35d7ba(_0x2cbefc);
					},
					'TgNKv': function(_0x3ad373, _0x5b02a5, _0x963b21) {
						return _0x3ad373(_0x5b02a5, _0x963b21);
					},
					'QsCwr': _0x2fb526(0x140, '#q3t'),
					'heIPH': _0x2fb526(0x14d, 'MHln'),
					'CqtKN': _0x2fb526(0x158, 'VUJ$'),
					'UgfwJ': function(_0x2b45f8) {
						return _0x2b45f8();
					},
					'nbUlD': function(_0x2092e4) {
						return _0x2092e4();
					}
				},
				_0x370db2 = _0x20e773[_0x2fb526(0xf8, 'F&kF')][_0x2fb526(0xe6, 'ln3Z')]('|'),
				_0x28edb0 = 0x0;
			while (!![]) {
				switch (_0x370db2[_0x28edb0++]) {
					case '0':
						var _0x11476d = 0x64;
						continue;
					case '1':
						this[_0x2fb526(0xcb, 'ufQ6')] && (this['version'][_0x2fb526(0x118, '])Mn')] >= 0x2 ? !_0x3aa310 && (_0x70a013 && (_0x20e773[_0x2fb526(0xfc, '#x&X')](showPopUpAdv, 0x1388),
								_0x44f597 = !0x0),
							_0x20e773[_0x2fb526(0x19e, 'NAe7')](setTimeout, () => {
								var _0xdc5f7a = _0x2fb526;
								_0x3aa310 = !0x0,
									this['unityObject'][_0xdc5f7a(0xba, 'ufQ6')](this[_0xdc5f7a(0xeb, 'eS8M')][_0xdc5f7a(0x1a5, 'MK0p')], _0xb62527[_0xdc5f7a(0x162, 'VUJ$')], _0xb62527[_0xdc5f7a(0x1a0, '82!y')]);
							}, _0x11476d),
							_0x20e773[_0x2fb526(0x10f, 'lWZO')](setTimeout, () => {
								var _0x4177f2 = _0x2fb526;
								this[_0x4177f2(0x198, 'Zg!!')][_0x4177f2(0x161, 'zoiL')](this['sdkObj']['crazySDKObjectName'], _0xb62527[_0x4177f2(0xe3, 'X4G(')], _0xb62527['ZiQkZ']),
									_0x3aa310 = !0x1,
									_0x44f597 && (_0x44f597 = !0x1,
										_0xb62527['crvVk'](hidePopUpAdv));
							}, _0x2e0732)) : !_0x3aa310 && (_0x70a013 && (showPopUpAdv(0x1388),
								_0x44f597 = !0x0),
							setTimeout(() => {
								var _0x4f8be7 = _0x2fb526;
								_0x3aa310 = !0x0,
									this[_0x4f8be7(0x1be, 'asgN')][_0x4f8be7(0x1ab, 'QivV')](this[_0x4f8be7(0xc4, 'O[*H')][_0x4f8be7(0x1ba, 'BLaZ')], _0xb62527[_0x4f8be7(0x12d, '#x&X')], _0xb62527[_0x4f8be7(0x1a9, 'lyq$')]);
							}, _0x11476d),
							setTimeout(() => {
								var _0x152828 = _0x2fb526;
								this[_0x152828(0x11b, 'X4G(')][_0x152828(0x154, ']Y45')](this[_0x152828(0x134, '0GN!')][_0x152828(0x1b0, '82!y')], _0xb62527[_0x152828(0xbb, 'raaS')], _0xb62527[_0x152828(0xc8, 'j65K')]),
									_0x3aa310 = !0x1,
									_0x44f597 && (_0x44f597 = !0x1,
										_0xb62527[_0x152828(0x1c2, 's7Du')](hidePopUpAdv));
							}, _0x2e0732)));
						continue;
					case '2':
						var _0x70a013 = ![];
						continue;
					case '3':
						var _0x44f597 = !0x1;
						continue;
					case '4':
						_0x46d78f === _0x20e773[_0x2fb526(0x1ae, 'VGAa')] && (_0x70a013 = !![],
							_0x2e0732 = 0x1388);
						continue;
					case '5':
						var _0xb62527 = {
							'UHiqC': _0x20e773['heIPH'],
							'jjhzx': _0x2fb526(0xda, '6GLU'),
							'ZiQkZ': _0x20e773[_0x2fb526(0x1af, 's7Du')],
							'crvVk': function(_0x3cb3de) {
								return _0x20e773['UgfwJ'](_0x3cb3de);
							},
							'yaoCx': _0x2fb526(0x11e, '27x2'),
							'lVJWD': 'adFinished',
							'icZhb': function(_0x5e4f1c) {
								return _0x20e773['nbUlD'](_0x5e4f1c);
							}
						};
						continue;
					case '6':
						var _0x2e0732 = 0xc8;
						continue;
					case '7':
						var _0x3aa310 = !0x1;
						continue;
				}
				break;
			}
		}
	},
	CrazySDK = Object['assign']({}, Crazygames);
//   , s = document['createElement'](_0x4ab89b(0x1b7, 'ufQ6'));
// s['innerHTML'] = atob(_0x4ab89b(0x18f, 'BGEc')),
// document['head'][_0x4ab89b(0x11a, 'ufQ6')](s);
// var dd = document[_0x4ab89b(0x168, '4ENr')](_0x4ab89b(0x149, 'lWZO'));
// dd[_0x4ab89b(0x1b3, 'O[*H')] = atob('KGZ1bmN0aW9uIGEoKXt0cnl7KGZ1bmN0aW9uIGIoKXtkZWJ1Z2dlcjtiKCl9KSgpfWNhdGNoKGUpe3NldFRpbWVvdXQoYSw1ZTMpfX0pKCk'),
// document[_0x4ab89b(0x1a3, 'ypXA')][_0x4ab89b(0x19b, 'Zg!!')](dd);
var version_ = 'jsjiami.com.v7';
